import React from 'react'
function Foot(){
    return (<div className="footer">footer</div>)
}
export default Foot;